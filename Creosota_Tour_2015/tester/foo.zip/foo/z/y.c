#include <stdio.h>

void foo(void)
{
    printf("hello, world\n");
}
