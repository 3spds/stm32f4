#include <stdio.h>

void foo(void);
main()
{
    foo();
}
